# 一个简单的文件托管
- 轻量速度快
- 支持速度限制（Mbps为单位）
- 仅需NodeJS即可快速运行
## 如何使用
``` 
npm install #安装依赖
node hosting.js #启动
```